package com.jacaranda.afdam.dojo.security.model.dto;

import java.time.LocalDateTime;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.jacaranda.afdam.dojo.model.dto.AlumnoDTO;
import com.jacaranda.afdam.dojo.model.dto.ProfesorDTO;
import com.jacaranda.afdam.dojo.security.model.User;
import com.jacaranda.afdam.dojo.security.model.enums.UserRole;


@Component
public class UserDTOConverter {

	// Inyectamos el servicio PasswordEncoder
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	
	// Convertimos de usuario a usuarioDto
	public UserDTO fromUserToUserDto(User user) {
		UserDTO dto = new UserDTO();
		dto.setUsername(user.getUsername());
		dto.setPassword(user.getPassword());
		dto.setRoles(user.getRoles());
		return dto;
	}
	
	// Convertimos de un usuarioDto a un Usuario
	public User fromUserDtoToUser(UserDTO dto) {
		User user = new User();
		user.setUsername(dto.getUsername());
		user.setPassword(dto.getPassword());
		return user;
	}
	
	// Convertimos de un AlumnoDto a un usuario
	public User fromAlumnoDtoToUser(AlumnoDTO dto) {
		User user = new User();
		user.setUsername(dto.getCurp());
		user.setPassword(passwordEncoder.encode(dto.getCurp()));
		user.setRoles(Set.of(UserRole.ALUMNO));
		user.setCreateTime(LocalDateTime.now());
		user.setUpdateTime(LocalDateTime.now());
		user.setLastPasswordChange(LocalDateTime.now());
		user.setLocked(false);
		user.setEnabled(true);
		user.setAuthenticationAttempts(0);
		user.setPasswordPolicyExpDate(LocalDateTime.now().plusDays(180));
		return user;
	}
	
	// Convertimos de un ProfesorDto a un usuario
	public User fromProfesorDtoToUser(ProfesorDTO dto) {
		User user = new User();
		user.setUsername(dto.getCurp());
		user.setPassword(passwordEncoder.encode(dto.getCurp()));
		user.setRoles(Set.of(UserRole.PROFESOR));
		user.setCreateTime(LocalDateTime.now());
		user.setUpdateTime(LocalDateTime.now());
		user.setLastPasswordChange(LocalDateTime.now());
		user.setLocked(false);
		user.setEnabled(true);
		user.setAuthenticationAttempts(0);
		user.setPasswordPolicyExpDate(LocalDateTime.now().plusDays(180));
		return user;
	}
	
}
