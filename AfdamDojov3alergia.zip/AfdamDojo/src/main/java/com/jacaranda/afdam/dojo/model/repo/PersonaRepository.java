package com.jacaranda.afdam.dojo.model.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.jacaranda.afdam.dojo.model.entity.Persona;

@Repository
public interface PersonaRepository extends JpaRepository<Persona, Integer> {
	
	public Persona findPersonaByName(String name);
	public Persona findPersonaByCurp(String curp);

	
	@Query(value= "SELECT * FROM Persona where name like ? or curp ? or email like ?", nativeQuery= true)
	public List<Persona> filterByNameOrCurpOrEmail(String filterName, String filterCurp, String filterEmail);
	
}
