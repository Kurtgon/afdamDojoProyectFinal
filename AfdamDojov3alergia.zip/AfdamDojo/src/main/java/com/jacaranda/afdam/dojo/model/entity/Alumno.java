package com.jacaranda.afdam.dojo.model.entity;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;

import com.jacaranda.afdam.dojo.model.entity.enums.TipoPago;


@Entity
@PrimaryKeyJoinColumn(name="personaId")//@DiscriminatorValue(value = "Alumno")
public class Alumno extends Persona {

	// ATRIBUTOS
	private String contact;
			
	@Enumerated(EnumType.STRING)
	@Column(name = "TipoPago", nullable = false)
	private TipoPago inscription;
	//private Set<TipoPago> inscription;
	

	// RELACIONES
	// Many to Many Alergia
	@ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE })
	@JoinTable(name="alumno_alergia",
	joinColumns = {@JoinColumn(name = "alumno_id", nullable = false)},
	inverseJoinColumns = {@JoinColumn(name = "alergia_id")})
	private Set<Alergia> allergys;
	
	// One to Many con clase
	@OneToMany(mappedBy = "alumno", cascade = CascadeType.ALL)
	private Set<Clase> classes;
	

	// CONSTRUCTOR
	public Alumno() {
		this.allergys = new HashSet<Alergia>();
		this.classes = new HashSet<Clase>();
	}

	public Alumno(String contact, TipoPago inscription) {
		super();
		this.contact = contact;
		this.inscription = inscription;
		this.allergys = new HashSet<Alergia>();
		this.classes = new HashSet<Clase>();
	}

	// GET y SET
	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}
		
	public TipoPago getInscription() {
		return inscription;
	}
	
	public void setInscription(TipoPago inscription) {
		this.inscription = inscription;
	}
	
	public Set<Alergia> getAllergys() {
		return allergys;
	}

	public void setAllergys(Set<Alergia> allergys) {
		this.allergys = allergys;
	}

	public Set<Clase> getClasses() {
		return classes;
	}

	public void setClasses(Set<Clase> classes) {
		this.classes = classes;
	}
	
	


}
