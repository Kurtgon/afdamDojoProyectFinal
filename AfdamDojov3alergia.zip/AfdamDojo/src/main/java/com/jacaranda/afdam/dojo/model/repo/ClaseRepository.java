package com.jacaranda.afdam.dojo.model.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jacaranda.afdam.dojo.model.entity.Clase;

public interface ClaseRepository extends JpaRepository<Clase, Integer> {
	
	
	
	public Clase findClaseById (int id);
	
	

}
