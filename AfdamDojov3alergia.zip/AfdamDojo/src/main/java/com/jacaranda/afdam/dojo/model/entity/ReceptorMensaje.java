package com.jacaranda.afdam.dojo.model.entity;

import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class ReceptorMensaje {
	
	// ATRIBUTOS
	@Id
	@Column(name = "receptor_mensaje_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_eliminacion")
	private Date delDate;

	@Column(name = "archivado")
	private boolean stored;
		
	@Column(name = "leido")
	private boolean read;
	
	@Column(name = "spam")
	private boolean spam;
	
	// RELACIONES
	/*
	// Many to One con Persona
	@ManyToOne
	@JoinColumn(name = "persona_id", foreignKey = @ForeignKey(name= "FK_receptor_mensaje_persona_id"))
	private Persona sender;
	*/
	// Many to One con Mensaje
	@ManyToOne
	@JoinColumn(name = "mensaje_id")
	private Mensaje mensaje;

	// CONSTRUCTOR
	public ReceptorMensaje() {
		super();
		
	}

	public ReceptorMensaje(boolean stored, Date delDate, boolean read, boolean spam, Persona sender, Mensaje mensaje) {
		super();
		this.stored = stored;
		this.delDate = delDate;
		this.read = read;
		this.spam = spam;
		//this.sender = sender;
		this.mensaje = mensaje;
	}

	// GET y SET
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDelDate() {
		return delDate;
	}
	
	public void setDelDate(Date delDate) {
		this.delDate = delDate;
	}
	
	public boolean isStored() {
		return stored;
	}

	public void setStored(boolean stored) {
		this.stored = stored;
	}


	public boolean isRead() {
		return read;
	}

	public void setRead(boolean read) {
		this.read = read;
	}

	public boolean isSpam() {
		return spam;
	}

	public void setSpam(boolean spam) {
		this.spam = spam;
	}
/*
	public Persona getSender() {
		return sender;
	}

	public void setSender(Persona sender) {
		this.sender = sender;
	}*/

	public Mensaje getMensaje() {
		return mensaje;
	}

	public void setMensaje(Mensaje mensaje) {
		this.mensaje = mensaje;
	}
	
}
