package com.jacaranda.afdam.dojo.model.entity;

import java.util.HashSet;
import java.util.Set;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.jacaranda.afdam.dojo.model.entity.enums.AlergiaGravedad;

@Entity
public class Alergia {

	// ATRIBUTOS
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@JsonProperty("alergyName")
	private String alergyName;
	
	@JsonProperty("serious")
	@Enumerated(EnumType.STRING)
	@Column(name = "Gravedad", nullable = false)
	private AlergiaGravedad serious;
		
	// RELACIONES
	// Con Alumno Many to Many
	@ManyToMany(mappedBy = "allergys")
	private Set<Alumno> students;
	
	/*
	@ManyToMany(targetEntity = Alumno.class, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	private Set<Alumno> students;
	 */
	
	// CONSTRUCTOR
	public Alergia() {
		this.students = new HashSet<>();
	}

	public Alergia(String alergyName, AlergiaGravedad serious) {
		super();
		this.alergyName = alergyName;
		this.serious = serious;//new HashSet<>();
		this.students = new HashSet<>();
	}
	
	
	// GET Y SET
	public String getAlergyName() {
		return alergyName;
	}

	public void setAlergyName(String alergyName) {
		this.alergyName = alergyName;
	}

		
	public AlergiaGravedad getSerious() {
		return serious;
	}
	
	public void setSerious(AlergiaGravedad serious) {
		this.serious = serious;
	}

	public Set<Alumno> getStudents() {
		return students;
	}

	public void setStudents(Set<Alumno> students) {
		this.students = students;
	}

}
