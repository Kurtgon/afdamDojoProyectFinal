package com.jacaranda.afdam.dojo.model.entity;

import java.sql.Blob;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.jacaranda.afdam.dojo.model.entity.enums.Disciplinas;
import com.jacaranda.afdam.dojo.security.model.User;

@Entity
@Table(name = "Persona")
@Inheritance(strategy =InheritanceType.JOINED )//@Inheritance(strategy = InheritanceType.SINGLE_TABLE)//@DiscriminatorColumn(name = "Persona_Puesto")
public abstract class Persona {

	// ATRIBUTOS
	/**
	 * Parameters: id lo genera de forma automática en la tabla curp debe ser único
	 * (similar al dni)
	 */
	@Id
	@Column(name = "persona_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name ="nombre")
	private String name;
	@Column(name ="apellidos")
	private String surnames;
	@Column(name="fecha_nacimiento")
	private String birthdate;

	@Column(unique = true)
	private String curp;

	@Column(name = "telefono")
	private String tlf;
	@Column(name = "direccion")
	private String address;
	@Column(name = "email")
	private String email;
	@Column(name = "foto_perfil")
	private Blob picture;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "Disciplina", nullable = false)
	private Disciplinas disciplina;
	
	@Column(name = "alta")
	private boolean register;

	
	// RELACIONES
	// Many To One con usuario
	@ManyToOne
	@JoinColumn(name = "userId", foreignKey = @ForeignKey(name="FK_USER_PERSONA"))
	private User user;
	
	/*
	// Many to Many Clase
	@ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	@JoinTable(name="persona_clase",
	joinColumns = {@JoinColumn(name = "persona_id", nullable = false)},
	inverseJoinColumns = {@JoinColumn(name = "clase_id")})
	private Set<Clase> classes;
	*/
	
	/*
	// One to Many con clase
	@OneToMany(mappedBy = "persona", cascade = CascadeType.ALL)
	private Set<Clase> classes;*/

	/*
	// Many to one con Mensaje
	@OneToMany(mappedBy = "emisor", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Mensaje>messages;
	
	// Many to one con ReceptorMensaje
	@OneToMany(mappedBy = "persona", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<ReceptorMensaje> receptorMensajes;
	
*/
	// CONSTRUCTOR

	public Persona() {
		super();
		//this.classes = new HashSet<Clase>();
		//this.messages = new ArrayList<Mensaje>();
		//this.receptorMensajes = new ArrayList<ReceptorMensaje>();
	}

	public Persona(String name, String surnames, String birthdate, String curp, String tlf, String address,
			String email, Blob picture, Disciplinas disciplina, boolean register) {
		super();
		this.name = name;
		this.surnames = surnames;
		this.birthdate = birthdate;
		this.curp = curp;
		this.tlf = tlf;
		this.address = address;
		this.email = email;
		this.picture = picture;
		this.disciplina = disciplina;
		//this.classes = new HashSet<Clase>();
		this.register = register;
		//this.messages = new ArrayList<Mensaje>();
		//this.receptorMensajes = new ArrayList<ReceptorMensaje>();
	}

	// GET Y SET
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getSurnames() {
		return surnames;
	}

	public void setSurnames(String surnames) {
		this.surnames = surnames;
	}

	public String getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String getCurp() {
		return curp;
	}

	public void setCurp(String curp) {
		this.curp = curp;
	}

	public String getTlf() {
		return tlf;
	}

	public void setTlf(String tlf) {
		this.tlf = tlf;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Blob getPicture() {
		return picture;
	}

	public void setPicture(Blob picture) {
		this.picture = picture;
	}
	
	
	public Disciplinas getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(Disciplinas disciplina) {
		this.disciplina = disciplina;
	}
	/*
	public Set<Clase> getClasses() {
		return classes;
	}

	public void setClasses(Set<Clase> classes) {
		this.classes = classes;
	}*/

	public boolean isRegister() {
		return register;
	}

	public void setRegister(boolean register) {
		this.register = register;
	}

	public User getUser() {
		return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}

	/*
	public List<Mensaje> getMessages(){
		return messages;
	}
	
	public void setMessages(List<Mensaje> messages) {
		this.messages = messages;
	}

	public List<ReceptorMensaje> getReceptorMensajes() {
		return receptorMensajes;
	}

	public void setReceptorMensajes(List<ReceptorMensaje> receptorMensajes) {
		this.receptorMensajes = receptorMensajes;
	}

	public Mensaje addMensaje(Mensaje message) {
		getMessages().add(message);
		message.setEmisor(this);
		
		return message;
	}
	
	public Mensaje deleteMensaje(Mensaje message) {
		getMessages().remove(message);
		message.setEmisor(null);
		
		return message;
	}
	
	public ReceptorMensaje addReceptorMensaje(ReceptorMensaje receptorMensaje) {
		getReceptorMensajes().add(receptorMensaje);
		receptorMensaje.setSender(this);
		
		return receptorMensaje;
	}
	
	public ReceptorMensaje deleteReceptorMensaje(ReceptorMensaje receptorMensaje) {
		getReceptorMensajes().add(receptorMensaje);
		receptorMensaje.setSender(null);
		
		return receptorMensaje;
	}
	*/
}
