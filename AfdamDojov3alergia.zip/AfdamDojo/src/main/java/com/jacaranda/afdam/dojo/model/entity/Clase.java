package com.jacaranda.afdam.dojo.model.entity;

import java.util.HashSet;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Clase {

	// ATRIBUTOS

	@Id
	@Column(name = "Clase_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "Días_Entreno", nullable = false)
	private String trainingDays;
	@Column(name = "Inicio_Clase", nullable = false)
	private String starHour;
	@Column(name = "Fin_Clase", nullable = false)
	private String endHour;

	// RELACIONES
	/*
	// Many to Many con Persona
	@ManyToMany(mappedBy = "classes")
	private Set<Persona> persons;
	*/
	
	//Many to One con Alumno
	@ManyToOne
	@JoinColumn(name = "AlumnoId", foreignKey = @ForeignKey(name="FK_ALUMNO_CLASE"))
	private Alumno alumno;
	
	//Many to One con Profesor
	@ManyToOne
	@JoinColumn(name = "ProfesorId", foreignKey = @ForeignKey(name="FK_PROFESOR_CLASE"))
	private Profesor profesor;
	

	// CONSTRUCTOR
	public Clase() {
		super();
		//this.persons = new HashSet<>();

	}

	public Clase(String trainingDays, String starHour, String endHour, Alumno alumno, Profesor profesor) {
		super();
		this.trainingDays = trainingDays;
		this.starHour = starHour;
		this.endHour = endHour;
		//this.persons = new HashSet<>();
		this.alumno = alumno;
		this.profesor = profesor;
	}

	// GET Y SET
	public int getId() {
		return id;
	}

	public String getTrainingDays() {
		return trainingDays;
	}

	public void setTrainingDays(String trainingDays) {
		this.trainingDays = trainingDays;
	}

	public String getStarHour() {
		return starHour;
	}

	public void setStarHour(String starHour) {
		this.starHour = starHour;
	}

	public String getEndHour() {
		return endHour;
	}

	public void setEndHour(String endHour) {
		this.endHour = endHour;
	}

	public Alumno getAlumno() {
		return alumno;
	}

	public void setAlumno(Alumno alumno) {
		this.alumno = alumno;
	}

	public Profesor getProfesor() {
		return profesor;
	}

	public void setProfesor(Profesor profesor) {
		this.profesor = profesor;
	}



	/*
	public Set<Persona> getPersons() {
		return persons;
	}

	public void setPersons(Set<Persona> persons) {
		this.persons = persons;
	}*/
	
	

}
