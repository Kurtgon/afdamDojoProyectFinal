package com.jacaranda.afdam.dojo.model.exceptions;

public class AlumnoException extends Exception{
	
	public AlumnoException(String msg) {
		
		super(msg);
	}

}
