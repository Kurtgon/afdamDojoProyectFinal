package com.jacaranda.afdam.dojo.model.entity;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Mensaje {

	// ATRIBUTOS
	@Id
	@Column(name = "mensaje_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "asunto")
	private String title;
	
	@Lob
	@Column(name = "cuerpo")
	private String description;
	

	@Column(name= "fecha")
	@Temporal(TemporalType.TIMESTAMP)
	private Date date;

	/*
	// RELACIONES
	// Many to One con Persona
	@ManyToOne
	@JoinColumn(name = "persona_id", foreignKey = @ForeignKey(name = "FK_remitente_mensaje_persona_id"))
	private Persona emisor;
	*/
	// Many to One con ReceptorMensaje
	@OneToMany(mappedBy = "mensaje")
	private List<ReceptorMensaje> receptormensajes;
	

	// CONSTRUCTOR
	public Mensaje() {
		super();
		this.receptormensajes = new ArrayList<ReceptorMensaje>();
	}

	public Mensaje(String title, String description, Date date, Persona emisor) {
		super();
		this.title = title;
		this.description = description;
		this.date = date;
		//this.emisor = emisor;
		this.receptormensajes = new ArrayList<ReceptorMensaje>();
	}

	// GET Y SET
	public int getId() {
		return id;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

/*
	public Persona getEmisor() {
		return emisor;
	}

	public void setEmisor(Persona emisor) {
		this.emisor = emisor;
	}
*/
	public List<ReceptorMensaje> getReceptormensajes() {
		return receptormensajes;
	}

	public void setReceptormensajes(List<ReceptorMensaje> receptormensajes) {
		this.receptormensajes = receptormensajes;
	}


	public ReceptorMensaje addReceptorMensaje(ReceptorMensaje receptorMensaje) {
		getReceptormensajes().add(receptorMensaje);
		receptorMensaje.setMensaje(this);
		
		return receptorMensaje;
	}
	
	public ReceptorMensaje deleteReceptorMensaje(ReceptorMensaje receptorMensaje) {
		getReceptormensajes().remove(receptorMensaje);
		receptorMensaje.setMensaje(null);
		
		return receptorMensaje;
	}
	
}
