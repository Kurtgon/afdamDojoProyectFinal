package com.jacaranda.afdam.dojo.model.entity;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;


import com.jacaranda.afdam.dojo.model.entity.enums.GradosInstructor;


@Entity
@PrimaryKeyJoinColumn(name="personaId")//@DiscriminatorValue(value = "Profesor")
public class Profesor extends Persona {

	// Atributos
	@Enumerated(EnumType.STRING)
	@Column(name = "Grado", nullable = false)
	private GradosInstructor grado;

	// RELACIONES
	// One to Many con clase
	@OneToMany(mappedBy = "profesor", cascade = CascadeType.ALL)
	private Set<Clase> classes;
	

	// CONSTRUCTOR

	public Profesor() {
		super();
		this.classes = new HashSet<>();
		
	}
	
	public Profesor(GradosInstructor grado) {
		super();
		this.grado = grado;
		this.classes = new HashSet<>();
		
	}

	// GET Y SET
	public GradosInstructor getGrado() {
		return grado;
	}

	public void setGrado(GradosInstructor grado) {
		this.grado = grado;
	}

	public Set<Clase> getClasses() {
		return classes;
	}

	public void setClasses(Set<Clase> classes) {
		this.classes = classes;
	}

	
	
}
