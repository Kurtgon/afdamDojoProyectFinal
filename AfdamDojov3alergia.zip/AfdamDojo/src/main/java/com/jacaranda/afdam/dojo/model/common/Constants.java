package com.jacaranda.afdam.dojo.model.common;

public class Constants {

	public static final String registrarUsuario = "http://localhost:8080/user/login";
	public static final int BONO = 5;
	public static final int MENSUAL = 30;
	public static final int ANUAL = 320;
	public static final int MATRICULA = 5;
}
