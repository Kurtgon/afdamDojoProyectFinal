package com.jacaranda.afdam.dojo.model.entity.enums;

public enum GradosInstructor {
	LOCAL,
	NACIONAL,
	INTERNACIONAL,
	WORD

}
