package com.jacaranda.AfdamDojo.model.entity.enums;

public enum TallaProducto {
XS,S,M,L,XL
}
