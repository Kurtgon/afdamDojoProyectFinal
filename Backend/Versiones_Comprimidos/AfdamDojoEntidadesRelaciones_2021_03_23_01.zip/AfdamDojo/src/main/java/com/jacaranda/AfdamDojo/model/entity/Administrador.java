package com.jacaranda.AfdamDojo.model.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "Administrador")
public class Administrador extends Persona {

	// Atributos

	// Constructor

	// Get y Set

}
