package com.jacaranda.AfdamDojo.model.entity.enums;

public enum AlergiaGravedad {
	LEVE, MODERADO, GRAVE;
}
