package com.jacaranda.afdam.dojo.model.common;

public class Constants {

	public static final String registrarUsuario = "http://localhost:8080/user/login";
	
}
