package com.jacaranda.afdam.dojo.model.exceptions;

public class UserException extends Exception {
	
	public UserException(String msg) {
		
		super(msg);
	}

}
