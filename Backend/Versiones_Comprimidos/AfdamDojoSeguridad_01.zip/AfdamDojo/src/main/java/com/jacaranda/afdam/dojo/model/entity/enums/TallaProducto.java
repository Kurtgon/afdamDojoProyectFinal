package com.jacaranda.afdam.dojo.model.entity.enums;

public enum TallaProducto {
XS,S,M,L,XL
}
