package com.jacaranda.afdam.dojo.model.common;

public class Constants {

	//Constantes para las fechas
	
}
