package com.jacaranda.afdam.dojo.model.exceptions;

public class ProfesorException extends Exception {
	
	public ProfesorException(String msg) {
		
		super(msg);
	}

}
