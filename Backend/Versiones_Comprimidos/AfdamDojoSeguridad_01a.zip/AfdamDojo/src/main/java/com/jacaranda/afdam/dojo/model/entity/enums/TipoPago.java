package com.jacaranda.afdam.dojo.model.entity.enums;

public enum TipoPago {
MENSUAL, BIMENSUAL
}
