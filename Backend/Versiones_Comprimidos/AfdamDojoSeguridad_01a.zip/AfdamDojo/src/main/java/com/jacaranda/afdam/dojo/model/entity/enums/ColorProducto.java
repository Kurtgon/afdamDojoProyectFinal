package com.jacaranda.afdam.dojo.model.entity.enums;

public enum ColorProducto {
BLANCO, AMARILLO, NARANJA, ROJO, VERDE, AZUL, NEGRO
}
