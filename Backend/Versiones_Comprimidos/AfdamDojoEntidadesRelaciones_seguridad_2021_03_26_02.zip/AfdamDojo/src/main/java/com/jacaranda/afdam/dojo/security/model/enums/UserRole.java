package com.jacaranda.afdam.dojo.security.model.enums;

public enum UserRole {
ADMIN, ALUMNO, PROFESOR
}
