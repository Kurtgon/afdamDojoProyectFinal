package com.jacaranda.afdam.dojo.model.entity.enums;

public enum CategoriaProducto {
	TRAINING, PROTECCIÓN, ARMA, ACCESORIO
}
