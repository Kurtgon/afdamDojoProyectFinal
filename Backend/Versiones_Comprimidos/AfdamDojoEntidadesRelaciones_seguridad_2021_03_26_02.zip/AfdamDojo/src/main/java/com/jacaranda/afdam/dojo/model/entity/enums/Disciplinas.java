package com.jacaranda.afdam.dojo.model.entity.enums;

public enum Disciplinas {
	
	KICKBOXING,
	MMA,
	CARDIOFITBAG,
	JIUJITSU,
	NINJUSTSU,
	TAICHI;

}
