import { Component, OnInit } from '@angular/core';
import { OpcionModel } from '@core/models/opciones.model';
import * as dataRaw from '../../../../data/opciones.json'

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  listaOpciones: Array<OpcionModel> = [];

  constructor() { }

  ngOnInit(): void {
    const {data}: any = (dataRaw as any).default
    this.listaOpciones = data;
  }

}
