import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FacturacionPageComponent } from './facturacion-page.component';

describe('FacturacionPageComponent', () => {
  let component: FacturacionPageComponent;
  let fixture: ComponentFixture<FacturacionPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FacturacionPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FacturacionPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
