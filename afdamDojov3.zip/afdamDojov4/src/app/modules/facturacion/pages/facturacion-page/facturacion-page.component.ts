import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facturacion-page',
  templateUrl: './facturacion-page.component.html',
  styleUrls: ['./facturacion-page.component.css']
})
export class FacturacionPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
