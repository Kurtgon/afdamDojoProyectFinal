import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notificaciones-page',
  templateUrl: './notificaciones-page.component.html',
  styleUrls: ['./notificaciones-page.component.css']
})
export class NotificacionesPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
