import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alumno-page',
  templateUrl: './alumno-page.component.html',
  styleUrls: ['./alumno-page.component.css']
})
export class AlumnoPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
