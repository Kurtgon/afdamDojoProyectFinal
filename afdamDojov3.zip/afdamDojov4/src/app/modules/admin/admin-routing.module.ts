import { HomeModule } from './../home/home.module';

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [

  {
    path: 'home',
    loadChildren:() => import('@modules/home/home.module').then(m => m.HomeModule)
  },
 
  {
    path: 'gestionUsuarios',
    loadChildren:() => import('@modules/gestion-usuarios/gestion-usuarios.module').then(m => m.GestionUsuariosModule)
  },

  {
    path: 'notificaciones',
    loadChildren:() => import('@modules/notificaciones/notificaciones.module').then(m => m.NotificacionesModule)
  },

  {
    path: 'facturacion',
    loadChildren:() => import('@modules/facturacion/facturacion.module').then(m => m.FacturacionModule)
  },

  {
    path: 'gestionTienda',
    loadChildren:() => import('@modules/gestion-tienda/gestion-tienda.module').then(m => m.GestionTiendaModule)
  },

  {
    path: '**', // No existe la ruta
    redirectTo: '/home' // Hay que cambiar esta ruta por la de home
  }
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
