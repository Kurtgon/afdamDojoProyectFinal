import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gestion-tienda-page',
  templateUrl: './gestion-tienda-page.component.html',
  styleUrls: ['./gestion-tienda-page.component.css']
})
export class GestionTiendaPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
