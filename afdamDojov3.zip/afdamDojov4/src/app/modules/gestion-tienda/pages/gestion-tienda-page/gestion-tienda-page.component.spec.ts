import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionTiendaPageComponent } from './gestion-tienda-page.component';

describe('GestionTiendaPageComponent', () => {
  let component: GestionTiendaPageComponent;
  let fixture: ComponentFixture<GestionTiendaPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GestionTiendaPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GestionTiendaPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
