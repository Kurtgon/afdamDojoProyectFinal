import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GestionTiendaRoutingModule } from './gestion-tienda-routing.module';
import { GestionTiendaPageComponent } from './pages/gestion-tienda-page/gestion-tienda-page.component';


@NgModule({
  declarations: [
    GestionTiendaPageComponent
  ],
  imports: [
    CommonModule,
    GestionTiendaRoutingModule
  ]
})
export class GestionTiendaModule { }
