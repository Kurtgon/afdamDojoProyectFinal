import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-gestion-usuarios-page',
  templateUrl: './gestion-usuarios-page.component.html',
  styleUrls: ['./gestion-usuarios-page.component.css']
})
export class GestionUsuariosPageComponent implements OnInit {

 
  constructor(private router:Router) { }

  ngOnInit(): void {
    
  }

  regresarHome(){
    this.router.navigate(['home']);
  }
}
