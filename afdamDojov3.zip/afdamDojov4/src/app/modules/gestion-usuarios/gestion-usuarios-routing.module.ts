import { GestionUsuariosPageComponent } from './pages/gestion-usuarios-page/gestion-usuarios-page.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddUsuarioComponent } from './components/add-usuario/add-usuario.component';
import { DetallesUsuarioComponent } from './components/detalles-usuario/detalles-usuario.component';



const routes: Routes = [
  {
    path: '',
    component: GestionUsuariosPageComponent,
    outlet:'child'
  },
  
  {path:'addUsuario', component: AddUsuarioComponent, outlet:'child'},
  {path:'detallesUsuario/:curp', component: DetallesUsuarioComponent, outlet:'child'}


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GestionUsuariosRoutingModule { }
