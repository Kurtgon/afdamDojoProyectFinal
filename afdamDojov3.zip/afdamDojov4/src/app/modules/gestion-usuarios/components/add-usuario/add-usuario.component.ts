import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, Validators, FormControl } from '@angular/forms';
import { Disciplina, Disciplinas } from '@core/models/disciplinaInterface';

@Component({
  selector: 'app-add-usuario',
  templateUrl: './add-usuario.component.html',
  styleUrls: ['./add-usuario.component.css']
})
export class AddUsuarioComponent implements OnInit {

  public formAddUser = new FormGroup({});

  disciplinas: Disciplina[] = [];

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.formAddUser = this.formBuilder.group({
      puesto: new FormControl('', [Validators.required]), /* Elegir alumno o profesor */
      name: new FormControl('', [Validators.required]),
      surnames: new FormControl('', [Validators.required]),
      birthdate: new FormControl('', [Validators.required]),
      curp: new FormControl('', [Validators.required]), /* Añadiremos la validación de mínimo y máximo de longitud */
      address: new FormControl(''),
      tlf: new FormControl('', [Validators.required]),
      contact: new FormControl(''),
      email: new FormControl('', [Validators.required, Validators.email]),
      picture: new FormControl(''),
      alergyName: new FormControl(''), /*Incluir un select con las alérgias */
      serious: new FormControl(''),
      discipline: new FormControl(''), /* Incluir un select con las disciplinas para el alumno */
      classes: new FormControl(''), /* Incluir un select con las clases de disciplinas que imparte el profesor */
      cuota: new FormControl('', [Validators.required]), /* Incluir un checkpoint con los tres tipos de cuota para el alumno */
      username: new FormControl('',[Validators.required]),
      password: new FormControl ('', [Validators.required,  Validators.minLength(8)])

    })
  }

  cargarDisciplinas(){
    this.disciplinas;
  }

}
