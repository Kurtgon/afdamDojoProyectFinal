import { ListaUsuariosComponent } from './../../../../shared/components/lista-usuarios/lista-usuarios.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalles-usuario',
  templateUrl: './detalles-usuario.component.html',
  styleUrls: ['./detalles-usuario.component.css']
})
export class DetallesUsuarioComponent implements OnInit {

  usuario:any = [{
    name:'Gonzalo',
    surname:'García Mateos',
    birthdate:'11/02/2000',
    curp:'1234567A',
    email:'gong@test.com',
    rol:'alumno',
    tlf:'654458741',
    alergyName:'No',
    picture:'',
    discipline:'Kickboxing'
  }]

  constructor() { }

  ngOnInit(): void {
    this.usuario;
  }

}
