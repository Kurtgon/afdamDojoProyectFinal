import { SharedModule } from './../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GestionUsuariosRoutingModule } from './gestion-usuarios-routing.module';
import { GestionUsuariosPageComponent } from './pages/gestion-usuarios-page/gestion-usuarios-page.component';
import { AddUsuarioComponent } from './components/add-usuario/add-usuario.component';

import { ReactiveFormsModule } from '@angular/forms';
import { DetallesUsuarioComponent } from './components/detalles-usuario/detalles-usuario.component';




@NgModule({
  declarations: [
    GestionUsuariosPageComponent,
    AddUsuarioComponent,
    DetallesUsuarioComponent
  
  ],
  imports: [
    CommonModule,
    GestionUsuariosRoutingModule,
    SharedModule,
    ReactiveFormsModule

  ]
})
export class GestionUsuariosModule { }
