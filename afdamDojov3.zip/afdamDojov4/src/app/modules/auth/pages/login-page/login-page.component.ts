import { AuthService } from './../../services/auth.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {

  formLogin= new FormGroup({});
  ocultarPassword: boolean = true;

  constructor(private formBuilder: FormBuilder, private authService:AuthService, private cookie: CookieService,
    private router: Router) { }

  ngOnInit(): void {
    this.formLogin = this.formBuilder.group({
      username: new FormControl('',[Validators.required]),
      password: new FormControl ('', [Validators.required,  Validators.minLength(8), Validators.maxLength(21)]) 
    });
  }

  enviar(): void {

    const { username, password } = this.formLogin.value;
    this.authService.enviarCredenciales(username,password).subscribe(responseOk => {
      console.log('Session Correcta', responseOk);
      // Guardar la cookie desde el componente
      const { tokenSession, data} = responseOk
      this.cookie.set('token',tokenSession, 7, '/') //número de días que tiene validez la cookie '/'para toda la aplicación
      this.router.navigate(['/', 'home']); //navegamos a la pagina principal de la aplicacion el home aun está pendiente de implementar
    },
    error => {
      console.log('Error con tu username o password')
      this.formLogin.reset();
    })

    
   
  }

}
