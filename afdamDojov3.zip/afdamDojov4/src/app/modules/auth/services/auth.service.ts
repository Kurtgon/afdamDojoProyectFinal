import { environment } from './../../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie-service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private readonly loginOk = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer:2000,
    timerProgressBar: true,
    didOpen: (toast)=> {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  }) 

  private readonly url = environment.loginUrl

  constructor(private http: HttpClient, private cookie: CookieService, private router: Router) { }

  // Método para enviar las credenciales de acceso a la aplicación
  enviarCredenciales(username: string, password: string): Observable<any> {

    const body = {
      username,
      password
    }
    
    return this.http.post(`${this.url}/login`, body).pipe(
      // Guardar la cookie desde un servicio
      tap((responseOk: any) => {
        if (responseOk != null && responseOk != undefined) {
          const { tokenSession, data } = responseOk;
          this.cookie.set('token_service', tokenSession, 7, '/');
            // Modal: cuadro de diálogo de credenciales correctas
            this.loginOk.fire({
            title: `Bienvenido  ${username}`,
            icon: 'success'
          });

          this.router.navigate(['/']);
        }
      },
        error => {
          Swal.fire({
            title: '<strong>Error, el username o el password no son correctos</strong>',
            icon:'error',
            confirmButtonColor: '#c80000',
            });
            
          console.log('Error en el username o en tu password')
        })
    );
  }

}
