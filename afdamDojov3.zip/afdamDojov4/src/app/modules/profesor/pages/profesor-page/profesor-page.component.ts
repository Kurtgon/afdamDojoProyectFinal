import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profesor-page',
  templateUrl: './profesor-page.component.html',
  styleUrls: ['./profesor-page.component.css']
})
export class ProfesorPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
