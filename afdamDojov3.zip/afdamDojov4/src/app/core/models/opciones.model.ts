export interface OpcionModel {
    titulo: string;
    cover: string;
    url: string;
}