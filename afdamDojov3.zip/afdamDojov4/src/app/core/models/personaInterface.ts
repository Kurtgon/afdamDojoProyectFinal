export interface Persona {
    name: string;
    surnames: string;
    curp: string;
    rol?: string; 
}