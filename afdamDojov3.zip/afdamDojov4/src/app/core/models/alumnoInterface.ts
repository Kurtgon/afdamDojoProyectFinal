import { User } from './userInterface';
export interface Alumno {
    name: string;
    surnames: string;
    birthdate: string;
    curp: string;
    tlf: string;
    address: string;
    email: string;
    contact: string;
    discipline?: string;
    allergy?: string;
    picture?: Blob;
    user: User;
}