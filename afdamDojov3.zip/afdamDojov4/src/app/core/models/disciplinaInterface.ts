export interface Disciplina {
    name: string;
}

export enum Disciplinas {
    KICKBOXING,
    MMA,
    CARDIOFITBAG,
    JIUJITSU,
    NINJUSTSU,
    TAICHI
}