import { OrderUsersPipe } from './order-users.pipe';

describe('OrderUsersPipe', () => {
  it('create an instance', () => {
    const pipe = new OrderUsersPipe();
    expect(pipe).toBeTruthy();
  });
});
