import { Persona } from './../../core/models/personaInterface';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderUsers'
})
export class OrderUsersPipe implements PipeTransform {

  transform(value: Array<any>, args: string | null = null, sort: string = 'asc'): Persona[] {

    try {

      if (args === null) {
        return value;
      } else {
        /* Función para ordenar */
        const listUserTemp = value.sort((a, b) => {
          if (a[args] < b[args]) {
            return -1
          }
          else if (a[args] === b[args]) {
            return 0;
          }
          else if (a[args] > b[args]) {
            return 1;
          }
          return 1
        });
        /* Si la lista es asc la devuelve tal cual sino la devuelve dsc*/
        return (sort === 'asc') ? listUserTemp : listUserTemp.reverse()
      }

      /* Capturamos el error pero al usuario le devolvemos el valor como estaba */
    } catch (error) {
      console.log('Algo no va bien',error);
      return value;
    }
  }

}
