import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: 'img[appImgBroken]'
})
export class ImgBrokenDirective {

  @Input() customImg: string = ''
  @HostListener('error') controlError():void {
    /* elemento nativo nos referimos a una de sus principales propiedades el src */
    const elementNativo = this.host.nativeElement
    /* cambiamos la imagen por la nuestra que hemos creado que será por defecto */
    elementNativo.src = this.customImg
  }
/* En el constructor hacemos referencia a un elemento "en este caso host" */
  constructor(private host: ElementRef) { }

}
