import { ImgBrokenDirective } from './img-broken.directive';

describe('ImgBrokenDirective', () => {
  it('should create an instance', () => {
    const directive = new ImgBrokenDirective();
    expect(directive).toBeTruthy();
  });
});
