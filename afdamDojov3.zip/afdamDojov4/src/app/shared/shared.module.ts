import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderUserComponent } from './components/header-user/header-user.component';
import { FooterComponent } from './components/footer/footer.component';
import { SideBarComponent } from './components/side-bar/side-bar.component';
import { PanelCardComponent } from './components/panel-card/panel-card.component';
import { SectionGenericComponent } from './components/section-generic/section-generic.component';
import { ListaUsuariosComponent } from './components/lista-usuarios/lista-usuarios.component';
import { RouterModule } from '@angular/router';
import { OrderUsersPipe } from './pipe/order-users.pipe';
import { ImgBrokenDirective } from './directives/img-broken.directive';
import { FormsModule } from '@angular/forms';





@NgModule({
  declarations: [
    HeaderUserComponent,
    FooterComponent,
    SideBarComponent,
    PanelCardComponent,
    SectionGenericComponent,
    ListaUsuariosComponent,
    OrderUsersPipe,
    ImgBrokenDirective
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule
  ],
  exports: [
    SideBarComponent,
    FooterComponent,
    PanelCardComponent,
    SectionGenericComponent,
    ListaUsuariosComponent,
    OrderUsersPipe,
    ImgBrokenDirective
  ]
})
export class SharedModule { }
