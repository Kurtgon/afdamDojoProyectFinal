import { OpcionModel } from './../../../core/models/opciones.model';
import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-panel-card',
  templateUrl: './panel-card.component.html',
  styleUrls: ['./panel-card.component.css']
})
export class PanelCardComponent implements OnInit {
  @Input() mode: 'big' = 'big';
  @Input() opcion: OpcionModel = {
    titulo: '',
    cover: '',
    url: ''
  }

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  entrar() {
    try {

      if (this.opcion.url === "gestionUsuarios") {
        this.router.navigate(['gestionUsuarios']);
      }

      if (this.opcion.url === "notificaciones") {
        this.router.navigate(['notificaciones'])
      }

      if (this.opcion.url === "facturacion") {
        this.router.navigate(['facturacion'])
      }

      if (this.opcion.url === "gestionTienda") {
        this.router.navigate(['gestionTienda'])
      }

    } catch (error) {

      console.log('Algo no va bien', error)

    }

  }

}
