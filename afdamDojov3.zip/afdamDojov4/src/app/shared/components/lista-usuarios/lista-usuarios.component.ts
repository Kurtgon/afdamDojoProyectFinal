import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-usuarios',
  templateUrl: './lista-usuarios.component.html',
  styleUrls: ['./lista-usuarios.component.css']
})
export class ListaUsuariosComponent implements OnInit {

  

  src: string = '';

  /* Declaramos el filtro que usaremos con el pipe para filtrar a los usuarios y lo iniciamos vacío*/
  filterUsers = '';

  /* Declaramos el filtro que usaremos con el pipe para ordenar la tabla de los usuarios pasando
     dos argumentos (la propiedad que puede null y el orden que será un string para indicar si es
      ascedente o descendete) */
  opcionesOrden: {property: string | null, order:string} = {property:null, order:'asc'}

  usuarios = [
    {
      name:'Gonzalo',
      surnames:'García Mateos',
      curp:'1234567A'
    },
    
    {
      name:'Alba',
      surnames:'Martin Roman',
      curp:'1234567B'
    },
    
    {
      name:'Juan',
      surnames:'Blanco Ruíz',
      curp:'987654123C'
    },

    {
      name:'Pedro',
      surnames:'Gutierrez Almado',
      curp:'78965412L'
    },

    {
      name:'Rosa',
      surnames:'Blanca Pérez',
      curp:'456123O'
    }
  ]
 

  constructor() { }

  ngOnInit(): void {
   
  }

  /* Creamos la función para cambiar el orden a los elementos de la tabla usuarios */
  cambiarOrden(property:string): void {
    /* Capturamos el orden */
    const { order } = this.opcionesOrden;
    /* Actualizamos el objeto */
    this.opcionesOrden = {
      property,
      order: order === 'asc' ? 'desc' : 'asc'
    }
  }

  busqueda(tipoBusqueda: string ): void {

    if(tipoBusqueda.length >= 3){

      console.log('Buscandpo por: ' , tipoBusqueda)

    }

  }

}
