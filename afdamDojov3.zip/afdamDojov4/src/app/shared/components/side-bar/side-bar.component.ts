import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.css']
})
export class SideBarComponent implements OnInit {

  mainMenu: { defaultOptions: Array<any>} = 
  {defaultOptions: []};

  constructor() { }

  ngOnInit(): void {
    this.mainMenu.defaultOptions = [
      {
        name: 'Home',
        icon: 'uil uil-estate',
        router: ['/','home']
      },
      {
        name: 'Gestión Usuarios',
        icon: 'uil uil-users-alt',
        router: ['/','gestionUsuarios']
      },
      
      {
        name: 'Notificaciones',
        icon: 'uil uil-bell',
        router: ['/','notificaciones']

      },

      {
        name: 'Facturación',
        icon: 'uil uil-receipt-alt',
        router: ['/','facturacion']
      },

      {
        name: 'Gestión Tienda',
        icon: 'class="uil uil-shopping-bag',
        router: ['/','gestionTienda']
      }
    ]
    
  }

}
