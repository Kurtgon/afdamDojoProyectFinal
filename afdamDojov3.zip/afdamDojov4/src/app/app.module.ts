import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/header/header.component';
import { LoginComponent } from './auth/login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'

import { ErrorTailorModule } from '@ngneat/error-tailor';
import { LoginPageComponent } from './auth/pages/login-page/login-page.component';
import { CookieService } from 'ngx-cookie-service';

@NgModule({
  declarations: [       /*Declaraciones, componentes, directivas, pipes */
    AppComponent,
    HeaderComponent,
    LoginComponent,
    LoginPageComponent
  ],
  imports: [            /* Solo se importa otros módulos*/
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
    
  ],
  providers: [CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
