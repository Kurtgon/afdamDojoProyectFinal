import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public formLogin= new FormGroup({});

  ocultarPassword: boolean = true;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.formLogin = this.formBuilder.group({
      //email: new FormControl ('', [Validators.required, Validators.email]),
      username: new FormControl('',[Validators.required]),
      password: new FormControl ('', [Validators.required,  Validators.minLength(8),
        Validators.pattern('^(?=.*[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*[!@#$&*?])(?=.*?[^\w\s]).{8,}$')]) 
        /* Condiciones del patrón de la expresión regular para la validación del password */
        /* Al menos ocho caracteres de longitud */
        /* Al menos un carácter en mínusculas */
        /* Al menos un carácter en mayúsculas */
        /* Al menos un carácter especial */
    });
  }

  enviar(): any {
    console.log(this.formLogin.value);
    this.formLogin.reset();
  }

}
