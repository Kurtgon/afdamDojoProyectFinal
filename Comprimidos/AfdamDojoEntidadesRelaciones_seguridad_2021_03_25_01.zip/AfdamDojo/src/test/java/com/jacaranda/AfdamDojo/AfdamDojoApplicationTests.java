package com.jacaranda.AfdamDojo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AfdamDojoApplicationTests {

	@Test
	void contextLoads() {
	}

}
