package com.jacaranda.AfdamDojo.model.entity.enums;

public enum TipoPago {
MENSUAL, BIMENSUAL
}
