package com.jacaranda.AfdamDojo.security.common;

public class SecurityConstants {

	public static final String SECRET = "GonzKeyToGenJWT_afdamD_@_GonzKeyToGenJWT_afdamD_@_GonzKeyToGenJWT_afdamD";
	public static final String SIGN_UP_URL = "/user/sign-up";
	public static final String LOG_IN = "/user/login";
	
}
