package com.jacaranda.AfdamDojo.model.common;

public class Constants {

	//Constantes para las fechas
	
}
