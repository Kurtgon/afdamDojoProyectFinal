package com.jacaranda.AfdamDojo.security.model.enums;

public enum UserRole {
ADMIN, ALUMNO, PROFESOR
}
