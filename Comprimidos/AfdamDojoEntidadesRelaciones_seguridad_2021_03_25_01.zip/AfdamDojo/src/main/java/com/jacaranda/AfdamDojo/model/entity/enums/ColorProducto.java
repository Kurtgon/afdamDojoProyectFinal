package com.jacaranda.AfdamDojo.model.entity.enums;

public enum ColorProducto {
BLANCO, AMARILLO, NARANJA, ROJO, VERDE, AZUL, NEGRO
}
