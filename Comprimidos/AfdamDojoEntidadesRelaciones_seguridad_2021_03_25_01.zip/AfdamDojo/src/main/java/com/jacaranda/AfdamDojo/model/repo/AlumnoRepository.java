package com.jacaranda.AfdamDojo.model.repo;

public class AlumnoRepository {

}
